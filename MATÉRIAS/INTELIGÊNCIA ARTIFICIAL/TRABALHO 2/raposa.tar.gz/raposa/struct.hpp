struct LastScore{
    int fox, goose;
};

LastScore lastScore;